import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'//public qovlugundan geldiyi ucun biz noqte yazmiriq buna
import './App.css'
import Header from './components/Header'
import MainComp from './components/MainComp'
import Footer from './components/Footer'

function App() {
 
  return (
    <>
    <Header/>
    <MainComp/>
    <Footer/>

    </>
  )
    
}

export default App
