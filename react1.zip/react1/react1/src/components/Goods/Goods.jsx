import styled from "styled-components";
import GoodsItem from "./GoodsItem";
import  goods  from "../../assets/data";


function Goods() {
    return(
        <div className="products">
            {goods.map((item)=> (
               <GoodsItem key={item.id} item={item} />
          
        ))}

        </div>
    )

    
}
export default Goods;