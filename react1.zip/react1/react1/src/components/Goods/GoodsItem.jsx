
function GoodsItem({item}) {
    return (
        <div className="products-item">
         
          <img src={item.url} alt={item.product_name} />
          <h3>{item.product_name}</h3>
          <p>{item.product_description}</p>
          <h2>Цена: {item.product_price} руб.</h2>
        </div>
      );
    
}
export default GoodsItem;