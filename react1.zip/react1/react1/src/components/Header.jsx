import styled from "styled-components";
import "../styles.css"
import '@fontsource/montserrat';

function Header() {
    return(
        <MainHeaderTag>
          <div style={{ fontFamily: 'Montserrat, sans-serif'}} className="logo">
          <HeaderTag>Интерьер.</HeaderTag>
          </div>
          <nav>
            <a href="#">Каталог</a>
            <a href="#">Корзина</a>
          </nav>
           
        </MainHeaderTag>
    )
    
}
export default Header


const MainHeaderTag = styled.header`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 20px;
  background-color: #ccc;
  width:1200px;
  margin-left:180px;
  
`;

const HeaderTag = styled.h6`
  color:#FFFFFF;
  font-size: 30px;
  font-weight: 900;
  fontFamily: 'Montserrat, sans-serif';

`;