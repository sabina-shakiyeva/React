import "../styles.css"
import Goods from "./Goods/Goods"


function MainComp() {
   
    return(
        
        <main>
             <div className="selection">
             <label htmlFor="sort">
             Порядок:
             </label>
             <select name="sort" id="sort">
                     <option value="new">новый</option>
                     <option value="old">старый</option>
                     <option value="expensive">дорогой</option>
                     <option value="cheap">дешевый</option>
                 </select>
         </div>
            <Goods/>
        </main>
    )
    
}
export default MainComp